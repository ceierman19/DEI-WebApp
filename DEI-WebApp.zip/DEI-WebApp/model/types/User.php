<?php
require_once(__DIR__."/Base.php");

class User extends Base {
    public $user_id, $email, $first_name, $last_name;
}