<?php
require_once(__DIR__."/../model/Database.php");
require_once(__DIR__."/../model/types/User.php");
Session::startSession();

class Session {
    static public function startSession() {
        session_start();
    }

    static public function initUserSession($email) {
       $results = Database::executeSql("select user_id, email, first_name, last_name from tblUsers where email = ?", "s", array($email));
       if (sizeof($results) > 0) {
           $user = new User($results[0]);
           self::setSessionUser($user);
           return true;
       }
       else {
           return false;
       }
    }

    static public function setSessionUser($user) {
        $_SESSION["user"] = json_encode($user);
    }

    static public function getSessionUser() : User {
        return new User(json_decode($_SESSION["user"]));
    }

    static public function isSessionValid(): bool {
        if (isset($_SESSION["userId"]) && $_SESSION["userId"] >= 0) {
            return true;
        }
        return false;
    }

    static public function destroySession() {
        $_SESSION["userId"] = null;
        session_unset();
        session_destroy();
    }

    static public function setProgram($program) {
        $_SESSION["program"] = $program;
    }

    static public function getProgram() {
        return $_SESSION["program"];
    }

    static public function setReportId($reportId) {
        $_SESSION["reportId"] = $reportId;
    }

    static public function getReportId() {
        return $_SESSION["reportId"];
    }
}