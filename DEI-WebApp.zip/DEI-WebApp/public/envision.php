<?php
    require_once("../common/header.php");
    showTitle("Step 1 - Envision | Diversity, Equity, and Inclusion Tool");

    //TODO Set reportId = session reportId
    $reportId = 1;

    if (isset($_POST["vision"])) {
        $vision = $_POST["vision"];
        $sql = "update tblReports set vision = ? where report_id = ?";
        Database::executeSql($sql, "si", array($vision, $reportId));
        // Uncomment to troubleshoot
        //print_r(Database::$lastError);
    }

    $results = Database::executeSql("select vision from tblReports where report_id = ?", "i", array($reportId));
    $vision = $results[0]["vision"];
?>

<div class="row">
    <div class="col-12 text-center">
        <h3>ENVISION</h3>
    </div>
</div>

<div class="row">
    <div class="col text-center">
        <img class="img-fluid" src="files/placeholder_image.png" alt="Placeholder image">
    </div>
</div><br />

<div class="row">
    <div class="col-6 text-center">
        <p>
            Begin by looking ahead 3 to 5 years and envision your department’s hopes in relation to equity,
            inclusion, and diversity. Some questions that might guide you include: <br /> <br />

            If we are successful in advancing diversity, equity, and inclusion, what would that look like 5
            years from now - in research, teaching, and in the community? What would our courses look like? What about
            our co-curricular activities? What would our student body in our majors look like? Our faculty and
            staff? How would we define a healthy departmental climate? What would our building and physical
            surroundings look like? Our promotional materials?
        </p>
    </div>

    <div class="col-6 text-center">
        <form action="envision.php" method="post">
            <div class="mb-3 row">
                <label for="vision" class="form-label text-center">Vision: </label>

                <div class="col-1"></div>

                <div class="col-10">
                    <textarea class="form-control" id="vision" placeholder="Enter your vision here." rows="4" name="vision"><?=$vision?></textarea><br />
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>

                <div class="col-1"></div>
            </div>
        </form>
    </div>
</div>

<?php
    require_once("../common/footer.php");
?>