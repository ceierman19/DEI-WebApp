<?php
    require_once("../common/header.php");
    showTitle("Home | Diversity, Equity, and Inclusion Tool");
?>

<div class="row">
    <div class="col-1"></div>

    <div class="col-4 text-center">
        <img class="img-fluid" src="files/hands.jpg" alt="Hands held together" id="handsImage"/>
    </div>

    <div class="col-6">
        <h2>DIVERSITY, EQUITY, AND INCLUSION TOOL</h2>
        <h5>Baldwin Wallace University</h5>
        <p>
            <b>Purpose<br /></b>
            The values of diversity and inclusion are interwoven throughout every strategic priority within BW’s
            Strategic Plan:
        </p>
        <ul>
            <li>Our Commitment to Learning: BW will continue a deep commitment to our diverse community of learners,
                supported by an engaged faculty and staff, dedicated to promoting student success.</li>
            <li>Our Commitment to Leadership: All students, faculty, and staff will experience a safe and welcoming
                campus climate that values and advances diversity and inclusion.</li>
            <li>Our Commitment to Industry and Community Partners: BW will partner with the region’s educational,
                cultural, social services, business, and community workforce ecosystem to continue instillment of our
                core values of diversity, inclusion, and equity.</li>
        </ul>
        <p>
            The Diversity, Inclusion, and Equity Tool is for internal use and will assist departments to assess and
            understand their department relating to diversity, inclusion, and equity. The tool will also help
            departments plan and implement needed adjustments. This tool is meant to help a department:
        </p>
            <ul>
                <li>self-audit their programs,</li>
                <li>reflect on areas of strength and in need of improvement,</li>
                <li>and then develop a plan and timeline to enhance diversity, inclusion, and equity.</li>
            </ul>
        </p>

        <div class="text-center"<br/><br/><h4>RESOURCES</h4></div>
        <ul>
            <li>FAQ</li>
            <li><a href="files/BestPractices.pdf" target="_blank">BEST PRACTICES</a></li>
            <li><a href="files/PlanningToolTimeline.pdf" target="_blank">PLANNING TOOL TIMELINE</a></li>
        </ul>
    </div>
</div>

<?php
    require_once("../common/footer.php");
?>