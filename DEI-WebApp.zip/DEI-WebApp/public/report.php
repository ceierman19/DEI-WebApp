<?php
    require_once("../common/header.php");
    showTitle("Report | Diversity, Equity, and Inclusion Tool");

    $reportId = 1;
    $vision_results = Database::executeSql("select vision from tblReports where report_id = ?", "i", array($reportId));
    $vision = $vision_results[0]["vision"];
    $assessments_reassessments = Database::executeSql("select tblIndicators.indicator_text, tblReportIndicators.indicator_assess_text, tblReportIndicators.indicator_reassess_text from tblIndicators inner join tblReportIndicators on tblIndicators.indicator_id=tblReportIndicators.indicator_id where report_id = ?", "i", array($reportId));
    $goals = Database::executeSql("select goal_text, goal_response from tblGoals where report_id = ?", "i", array($reportId));
?>

<div class="mb-3 row" id="reportPage">
    <div class="col-1"></div>
    <div class="col-11" id="div">
        <div class="container">
            <!-- TODO Format report -->
            <!-- TODO Include selected program and report date -->
            <h1>Report For PROGRAM - 4/20/2023</h1>
            <h2>Vision</h2>
            <p>
                <?=$vision?>
            </p>

            <h2>Initial Assessment and Reassessment of Indicators</h2>
            <?php
                foreach ($assessments_reassessments as $assess_reassess) {
                    ?>
                    <h3><?=$assess_reassess["indicator_text"]?></h3>
                    <b>Initial Assessment</b>
                    <p>
                        <?=$assess_reassess["indicator_assess_text"]?>
                    </p>
                    <b>Reassessment</b>
                    <p>
                        <?=$assess_reassess["indicator_reassess_text"]?>
                    </p>
                    <?php
                }
            ?>

            <h2>Goals</h2>
            <?php
                $i = 1;
                foreach ($goals as $goal) {
                    ?>
                    <h3>Goal #<?=$i?></h3>
                    <b>Description of Goal</b>
                    <p>
                        <?=$goal["goal_text"]?>
                    </p>
                    <b>Evaluation of Goal</b>
                    <p>
                        <?=$goal["goal_response"]?>
                    </p>
                    <?php
                    $i++;
                }
            ?>
        </div>
    </div>
</div>

<?php
    require_once("../common/footer.php");
?>