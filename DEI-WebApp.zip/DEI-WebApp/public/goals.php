<?php
    require_once("../common/header.php");

    if ($_GET["action"] == "delete") {
        $gid = $_GET["goal_id"];
        $sql = "delete from tblGoals where goal_id = ?";
        Database::executeSql($sql, "i", array($gid));
        header("Location: goals.php");
    }

    showTitle("Step 3 - Goals and Action Plan | Diversity, Equity, and Inclusion Tool");

    $reportId = 1;

    if (isset($_POST["action"])) {
        $ids = explode(",", $_POST["ids"]);

        foreach($ids as $id) {
            if ($id == null) {
                continue;
            }
            $gid = $_POST["goal_id_".$id];
            $goal_text = $_POST["goal_text_".$id];
            $goal_response = $_POST["goal_response_".$id];
            $sql = "update tblGoals set goal_text = ?, goal_response = ? where goal_id = ? and report_id = ?";
            Database::executeSql($sql, "ssii", array($goal_text, $goal_response, $gid, $reportId));
            print_r(Database::$lastError);
        }

        for ($i = 0; $i < $_POST["newFields"]; $i++) {
            $new_goal_text = $_POST["goal_text_new_".($i + $_POST["initial_fields"])];
            $new_goal_response = $_POST["goal_response_new_".($i + $_POST["initial_fields"])];
            $new_sql = "insert into tblGoals (goal_text, goal_response, report_id) values (?,?,?)";
            Database::executeSql($new_sql, "ssi", array($new_goal_text, $new_goal_response, $reportId));
        }
    }

    $results = Database::executeSql("select * from tblGoals where report_id = ?", "i", array($reportId));
?>

<div class="row">
    <div class="col text-center">
        <h3>GOALS</h3>
        <p>SMART Goals (Specific, Measurable, Achievable, Relevant, Time-bound)</p>
    </div>
</div>

<div class="row">
    <div class="col text-center">
        <img class="img-fluid" src="files/placeholder_image.png" alt="Placeholder image">
    </div>
</div><br />

<script src="../public/js/goals1.js"></script>

<div class="modal fade" id="deleteGoalModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this goal?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="btnDeleteGoal">Delete</button>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col text-center">
        <button id="btnAddGoal" type="button" class="btn btn-primary">Add Goal</button><br/><br/>
        <form action="goals.php" method="post">
            <div id="goalFields">
            <input type="hidden" name="action" value="update"/>
            <input type="hidden" name="initialFields" value="<?=sizeof($results)?>"/>
            <input type="hidden" name="newFields" id="newFields" value="0"/>
            <?php
            $ids = "";
            for ($i = 0; $i < sizeof($results); $i++) {
                ?>
                <div class="mb-3 row" id="<?=($i == 0) ? "initial" : ""?>">
                    <label for="goalText" class="col-sm-1 col-form-label">Goal: </label>

                    <div class="col-sm-10">
                        <input type="hidden" name="goal_id_<?=$results[$i]["goal_id"]?>"
                               value="<?=$results[$i]["goal_id"]?>"/>
                        <textarea class="form-control" id="goalText"
                                  name="goal_text_<?=$results[$i]["goal_id"]?>"
                                  placeholder="Type goal here."
                                  rows="3"><?=$results[$i]["goal_text"]?></textarea><br/>
                    </div>

                    <div class="col-sm-1">
                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteGoalModal" data-bs-id="<?=$results[$i]["goal_id"]?>">Delete</button>
                    </div>

                    <div class="mb-3">
                        <input type="hidden" name="goal_id_<?=$results[$i]["goal_id"]?>"
                               value="<?=$results[$i]["goal_id"]?>"/>
                        <textarea class="form-control" id="goalResponse"
                                  name="goal_response_<?=$results[$i]["goal_id"]?>"
                                  placeholder="Enter your response here."
                                  rows="3"><?=$results[$i]["goal_response"]?></textarea>
                    </div>
                </div>

                <?php
                $ids = $ids.$results[$i]["goal_id"].",";
            }
            ?>
            </div>
            <button type="submit" class="btn btn-primary">Save</button>
            <input type="hidden" name="ids" value="<?=$ids?>"/>
        </form>
    </div>
</div><br/>

<script src="../public/js/goals2.js"></script>

<?php
    require_once("../common/footer.php");
?>