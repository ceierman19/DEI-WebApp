<?php
    require_once("../common/header.php");
    if ($_GET["action"] == "delete") {
        $rid = $_GET["report_indicator_id"];
        $sql = "delete from tblReportIndicators where report_indicator_id = ?";
        Database::executeSql($sql, "i", array($rid));
        header("Location: assess.php");
    }
    showTitle("Step 2 - Assess | Diversity, Equity, and Inclusion Tool");

    // connect to report dropdown, which should pull from the db
    $reportId = 1;

    if (isset($_POST["action"])) {
        $ids = explode(",", $_POST["ids"]);

        foreach($ids as $id) {
            if ($id == null) {
                continue;
            }
            $assessment = $_POST["indicator_assess_text_".$id];
            $iid = $_POST["indicator_id_".$id];
            $rid = $_POST["report_indicator_id_".$id];
            $sql = "update tblReportIndicators set indicator_assess_text = ?, indicator_id = ? where report_indicator_id = ? and report_id = ?";
            Database::executeSql($sql, "siii", array($assessment, $iid, $rid, $reportId));
        }

        for ($i = 0; $i < $_POST["newFields"]; $i++) {
            $new_assessment = $_POST["indicator_assess_text_new_".($i + $_POST["initial_fields"])];
            $new_iid = $_POST["indicator_id_new_".($i + $_POST["initial_fields"])];
            $new_reassessment = "";
            $new_sql = "insert into tblReportIndicators (indicator_assess_text, indicator_id, report_id, indicator_reassess_text) values (?,?,?,?)";
            Database::executeSql($new_sql, "siis", array($new_assessment, $new_iid, $reportId, $new_reassessment));
        }
    }

    $results = Database::executeSql("select * from tblReportIndicators where report_id = ?", "i", array($reportId));

    $indicators = Database::executeSql("select indicator_id, indicator_text from tblIndicators ORDER BY indicator_id");
?>

<script src="../public/js/assess1.js"></script>

<div class="modal fade" id="deleteIndicatorModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this indicator?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="btnDeleteIndicator">Delete</button>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12 text-center">
        <h3>ASSESS</h3>
    </div>
</div>

<div class="row">
    <div class="col-6 text-center">
        <img class="img-fluid" src="files/placeholder_image.png" alt="Placeholder image">
    </div>

    <div class="col-6 text-center">
        <p>
            Using the results of <i>Step 1 - Envision</i> as a guide, pick one or two
            <a href="files/EducationalIndicators.pdf" target="_blank">Educational Indicators of Inclusion</a>.
            <b>Climate</b> should be assessed every cycle. Resources to help you assess are listed below.<br/><br/>
            <a href="files/EdIndicatorsSuggestedAssessmentActivities.pdf" target="_blank">Educational
                Indicators, Suggested Assessment Activities, and Additional Resources for Each
                Indicator</a><br/><br/>
            <a href="files/MoreConsiderationsEducationalIndicators.pdf" target="_blank">Additional
                Considerations on Each Indicator</a><br/><br/>
            <a href="files/StudentFocusGroupTemplate.docx" target="_blank">Student Focus Group
                Template</a><br/><br/>
            <a href="files/SampleSurveyQuestions.docx" target="_blank">Sample Survey Questions</a><br/><br/>
            <a href="files/CourseContentStructureSurvey.docx" target="_blank">Questions to Assess Course
                Content/Structure</a><br/><br/>
            <a href="files/SampleSyllabusChecklist.docx" target="_blank">Sample Syllabus Checklist</a>
        </p>
    </div>
</div><br/>

<div class="row">
    <div class="col text-center">
        <button id="btnAddIndicatorAssessment" type="button" class="btn btn-primary">Add Indicator to Assess</button><br/><br/>
        <form action="assess.php" method="post">
            <div id="indicatorFields">
            <input type="hidden" name="action" value="update"/>
            <input type="hidden" name="initialFields" value="<?=sizeof($results)?>"/>
            <input type="hidden" name="newFields" id="newFields" value="0"/>
            <?php
            $ids = "";
            for ($i = 0; $i < sizeof($results); $i++) {
                ?>
                <div class="mb-3 row" id="<?=($i == 0) ? "initial" : ""?>">
                    <label for="indicatorDropdown" class="col-sm-1 col-form-label">Indicator: </label>

                    <?php
                    if ($results[$i]["indicator_id"] == 1) {
                        ?>

                        <div class="col-sm-10">
                            <select class="form-select" id="indicatorDropdown" name="indicator_id_<?=$results[$i]["report_indicator_id"]?>">
                                <?php
                                    foreach ($indicators as $indicator) {
                                        echo "<option value='" . $indicator["indicator_id"] . "'";
                                        if ($indicator["indicator_id"] == $results[$i]["indicator_id"]) {
                                            echo " selected ";
                                        }
                                        echo ">" . $indicator["indicator_text"];
                                        echo "</option>";
                                    }
                                ?>
                            </select><br/>
                        </div>

                        <?php
                    } else {
                        ?>

                        <div class="col-sm-10">
                            <select class="form-select" id="indicatorDropdown" name="indicator_id_<?=$results[$i]["report_indicator_id"]?>">
                                <?php
                                    foreach ($indicators as $indicator) {
                                        echo "<option value='" . $indicator["indicator_id"] . "'";
                                        if ($indicator["indicator_id"] == $results[$i]["indicator_id"]) {
                                            echo " selected ";
                                        }
                                        echo ">" . $indicator["indicator_text"];
                                        echo "</option>";
                                    }
                                ?>
                            </select><br/>
                        </div>

                        <?php
                    }
                    ?>

                    <div class="col-sm-1">
                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteIndicatorModal" data-bs-id="<?=$results[$i]["report_indicator_id"]?>">Delete</button>
                    </div>

                    <div class="mb-3">
                        <input type="hidden" name="report_indicator_id_<?=$results[$i]["report_indicator_id"]?>"
                               value="<?=$results[$i]["report_indicator_id"]?>"/>
                        <textarea class="form-control" id="indicatorAssessment"
                                  name="indicator_assess_text_<?=$results[$i]["report_indicator_id"]?>"
                                  placeholder="Enter your response here."
                                  rows="3"><?=$results[$i]["indicator_assess_text"]?></textarea>
                    </div>
                </div>

                <?php
                $ids = $ids.$results[$i]["report_indicator_id"].",";
            }
            ?>
            </div>
            <button type="submit" class="btn btn-primary">Save</button>
            <input type="hidden" name="ids" value="<?=$ids?>"/>
        </form>
    </div>
</div><br/>

<script src="../public/js/assess2.js"></script>

<?php
    require_once("../common/footer.php");
?>