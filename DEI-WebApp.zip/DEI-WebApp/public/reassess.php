<?php
    require_once("../common/header.php");
    showTitle("Step 4 - Reassess | Diversity, Equity, and Inclusion Tool");

    $reportId = 1;

    if (isset($_POST["action"])) {
        $ids = explode(",", $_POST["ids"]);

        foreach($ids as $id) {
            if ($id == null) {
                continue;
            }
            $reassessment = $_POST["indicator_reassess_text_".$id];
            $iid = $_POST["indicator_id_".$id];
            $rid = $_POST["report_indicator_id_".$id];
            $sql = "update tblReportIndicators set indicator_reassess_text = ?, indicator_id = ? where report_indicator_id = ? and report_id = ?";
            Database::executeSql($sql, "siii", array($reassessment, $iid, $rid, $reportId));
        }
    }

    $results = Database::executeSql("select * from tblReportIndicators where report_id = ?", "i", array($reportId));

    $indicators = Database::executeSql("select indicator_id, indicator_text from tblIndicators ORDER BY indicator_id");
?>

<div class="row">
    <div class="col-12 text-center">
        <h3>REASSESS</h3>
    </div>
</div>

<div class="row">
    <div class="col-6 text-center">
        <img class="img-fluid" src="files/placeholder_image.png" alt="Placeholder image">
    </div>

    <div class="col-6 text-center">
        <p>
            After strategies and deliverables are completed, reassess using the metrics outlined in the goal sheet.
            <br /><br />
            <a href="files/EdIndicatorsSuggestedAssessmentActivities.pdf" target="_blank">Educational Indicators,
                Suggested Assessment Activities, and Additional Resources for Each Indicator</a><br /><br />
            <a href="files/MoreConsiderationsEducationalIndicators.pdf" target="_blank">Additional Considerations on
                Each Indicator</a><br /><br />
            <a href="files/StudentFocusGroupTemplate.docx" target="_blank">Student Focus Group Template</a><br /><br />
            <a href="files/SampleSurveyQuestions.docx" target="_blank">Sample Survey Questions</a><br /><br />
            <a href="files/CourseContentStructureSurvey.docx" target="_blank">Questions to Assess Course
                Content/Structure</a><br /><br />
            <a href="files/SampleSyllabusChecklist.docx" target="_blank">Sample Syllabus Checklist</a>
        </p>
    </div>
</div><br/>

<div class="row">
    <div class="col text-center">
        <form action="reassess.php" method="post">
            <input type="hidden" name="action" value="update"/>
            <?php
            $ids = "";
            for ($i = 0; $i < sizeof($results); $i++) {
                ?>
                <div class="mb-3 row">
                    <label for="indicatorDropdown" class="col-sm-1 col-form-label">Indicator: </label>

                    <?php
                    if ($results[$i]["indicator_id"] == 1) {
                        ?>

                        <div class="col-sm-11">
                            <select class="form-select" id="indicatorDropdown" name="indicator_id_<?=$results[$i]["report_indicator_id"]?>">
                                <?php
                                foreach ($indicators as $indicator) {
                                    echo "<option value='" . $indicator["indicator_id"] . "'";
                                    if ($indicator['indicator_id'] == $results[$i]['indicator_id']) {
                                        echo " selected ";
                                    }
                                    echo ">" . $indicator["indicator_text"];
                                    echo "</option>";
                                }
                                ?>
                            </select><br/>
                        </div>

                        <?php
                    } else {
                        ?>

                        <div class="col-sm-11">
                            <select class="form-select" id="indicatorDropdown" name="indicator_id_<?=$results[$i]["report_indicator_id"]?>">
                                <?php
                                foreach ($indicators as $indicator) {
                                    echo "<option value='" . $indicator["indicator_id"] . "'";
                                    if ($indicator['indicator_id'] == $results[$i]['indicator_id']) {
                                        echo " selected ";
                                    }
                                    echo ">" . $indicator["indicator_text"];
                                    echo "</option>";
                                }
                                ?>
                            </select><br/>
                        </div>

                        <?php
                    }
                    ?>

                    <div class="mb-3">
                        <input type="hidden" name="report_indicator_id_<?= $results[$i]['report_indicator_id'] ?>"
                               value="<?= $results[$i]['report_indicator_id'] ?>"/>
                        <textarea class="form-control" id="indicatorReassessment"
                                  name="indicator_reassess_text_<?= $results[$i]['report_indicator_id'] ?>"
                                  placeholder="Enter your response here."
                                  rows="3"><?= $results[$i]['indicator_reassess_text'] ?></textarea>
                    </div>
                </div>

                <?php
                $ids = $ids.$results[$i]['report_indicator_id'].",";
            }
            ?>

            <button type="submit" class="btn btn-primary">Save</button>
            <input type="hidden" name="ids" value="<?=$ids?>"/>
        </form>
    </div>
</div><br/>

<?php
    require_once("../common/footer.php");
?>