<?php
    require_once("../common/header.php");
    showTitle("My Programs | Diversity, Equity, and Inclusion Tool");
?>

<div class="row">
    <div class="col text-center">
        <form>
            <div class="mb-3 row">
                <label for="programsDropdown" class="col-2 col-form-label">Select Program: </label>

                <div class="col-8">
                    <select class="form-select" id="programsDropdown">
                        <?php
                            //TODO Set session program to whatever program the user selects

                            $programs = Database::executeSql("select program_id, program_name from tblPrograms ORDER BY program_id");

                            foreach ($programs as $program) {
                                echo "<option value='" . $program["program_id"] . "'>" . $program["program_name"] . "</option>";
                            }
                        ?>
                    </select><br/>
                </div>
            </div>

            <div class="mb-3 row">
                <label for="reportsDropdown" class="col-2 col-form-label">Select Report: </label>

                <div class="col-8">
                    <select class="form-select" id="reportsDropdown">
                        <?php
                            //TODO Include report dates in dropdown
                            //TODO Add option to create new report in dropdown
                            //TODO Set session reportId to whatever report the user selects

                            $reports = Database::executeSql("select report_id, start_date from tblReports ORDER BY report_id");

                            foreach ($reports as $report) {
                                echo "<option value='" . $report["start_date"] . "'>" . $report["report_id"] . "</option>";
                            }
                        ?>
                    </select><br/>
                </div>

                <div class="col-2"></div>

                <a class="mb-3">
                    <button type="button" class="btn btn-primary" onclick="location.href='envision.php'">Let's Go</button>
            </div>
        </form>
    </div>
</div><br/>

<?php
    require_once("../common/footer.php");
?>