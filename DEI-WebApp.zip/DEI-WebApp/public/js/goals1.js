var initialFields = 0;

function copy() {
    var fields = document.getElementById("goalFields").querySelectorAll(".col-sm-1-col-form-label");

    if (initialFields === 0) {
        initialFields = fields.length;
    }

    var goal = document.getElementById("initial").cloneNode(true);
    goal.querySelector("textarea").value = "";
    goal.querySelector("#goalResponse").value = "";
    goal.querySelector("#goalText").name = "goal_text_new_" + document.getElementById("newFields").value;
    goal.querySelector("#goalResponse").name = "goal_response_new_" + document.getElementById("newFields").value;
    document.getElementById("newFields").value++;
    document.getElementById("goalFields").appendChild(goal);
}