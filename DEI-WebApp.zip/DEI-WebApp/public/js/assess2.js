document.getElementById("btnAddIndicatorAssessment").onclick = (event) => copy();

var deleteModal = document.getElementById("deleteIndicatorModal");
var reportIndicatorIdToDelete;

deleteModal.querySelector("#btnDeleteIndicator").addEventListener("click", function event() {
    window.location = "assess.php?action=delete&report_indicator_id=" + reportIndicatorIdToDelete;
});

deleteModal.addEventListener("show.bs.modal", function (event) {
    let sourceButton = event.relatedTarget;
    reportIndicatorIdToDelete = sourceButton.getAttribute("data-bs-id");
});