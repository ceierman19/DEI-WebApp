document.getElementById("btnAddGoal").onclick = (event) => copy();

var deleteModal = document.getElementById("deleteGoalModal");
var goalIdToDelete;

deleteModal.querySelector("#btnDeleteGoal").addEventListener("click", function event() {
    window.location = "goals.php?action=delete&goal_id=" + goalIdToDelete;
});

deleteModal.addEventListener("show.bs.modal", function (event) {
    let sourceButton = event.relatedTarget;
    goalIdToDelete = sourceButton.getAttribute("data-bs-id");
});