var initialFields = 0;

function copy() {
    var fields = document.getElementById("indicatorFields").querySelectorAll(".form-select");

    if (initialFields === 0) {
        initialFields = fields.length;
    }

    var indicator = document.getElementById("initial").cloneNode(true);
    indicator.querySelector("textarea").value = "";
    indicator.querySelector("#indicatorDropdown").name = "indicator_id_new_" + document.getElementById("newFields").value;
    indicator.querySelector("#indicatorAssessment").name = "indicator_assess_text_new_" + document.getElementById("newFields").value;
    document.getElementById("newFields").value++;
    document.getElementById("indicatorFields").appendChild(indicator);
}