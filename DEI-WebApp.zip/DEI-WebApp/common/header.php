<?php
    require_once("../model/Database.php");
    require_once("../lib/Session.php");

    $msauthResult = null;
    // Check if we got back an auth result
    if (isset($_SESSION["MSAUTH_RESULT"])) {
        $msauthResult = json_decode($_SESSION["MSAUTH_RESULT"]);
    }

    // If we got back a username and we did not yet set the session username, try to init a session
    // Note: The user MUST have an account setup in the database
    if (isset($msauthResult->username) && ! isset($_SESSION["username"])) {
        // handle auth result
        $auth_result = json_decode($_SESSION["MSAUTH_RESULT"]);
        $success = Session::initUserSession($auth_result->username);
        if (!$success) {
            die("The user " . Session::getSessionUser()->email . " is not authorized to access this application. Please contact the administrator or login as a different user.");
        }
    }
    else {
        // Redirect the user to login
        $currentPage = "https://$_SERVER[HTTP_HOST]$_SERVER[PHP_SELF]";
        header("Location: https://$_SERVER[HTTP_HOST]/common/msauth.php?auth_request=$currentPage");
    }

    $user = Session::getSessionUser();

    function highlightNavPage($link) {
        if (basename($_SERVER["PHP_SELF"]) == $link) {
            return "active";
        }
    }

    function shouldHideSubNav($array) {
        $found = false;

        foreach($array as $link => $val) {
            if (basename($_SERVER["PHP_SELF"]) == $link) {
                $found = true;
            }
        }

        if (!$found) {
            return "no-show";
        }
    }

    function showTitle($title) {
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?=$title?></title>
    <link rel="stylesheet" href="../public/css/bootstrap.min.css">
    <script src="../public/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../public/css/style.css">
    <link rel="stylesheet" href="../public/css/report.css">
</head>

<body>
    <div class="container" id="mainContent"><br/>
        <div class="row">
            <div class="col-7">
                <h2>DIVERSITY, EQUITY, AND INCLUSION TOOL</h2>
            </div>

            <div class="col-5 mx-auto" id="programsDropdownSection">
                <div class="row flex-lg-nowrap">
                    <label for="programsDropdown" class="col-auto col-form-label"> Selected Program: </label>

                    <select class="col-auto form-select" id="programsDropdown">
                        <?php
                            //TODO Change program dropdown to read-only field -- should match the selected program in My Programs page

                            $programs = Database::executeSql("select program_id, program_name from tblPrograms ORDER BY program_id");

                            foreach($programs as $program) {
                                echo "<option value='" . $program["program_id"]. "'>" . $program["program_name"]. "</option>";
                            }
                        ?>
                    </select><br />
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-9">
                <ul class="nav justify-content-start">
                    <?php
                        $links = array(
                                "index.php" => "Home",
                                "programs.php" => "My Programs",
                                "envision.php" => "Let's Go"
                        );

                        foreach($links as $link => $val) {
                            //TODO Add logic to only show Let's Go tab if session report & program are set

                            ?>
                            <a class="nav-link <?=highlightNavPage($link)?>" aria-current="page" href="<?=$link?>"><?=$val?></a>
                            <?php
                        }
                    ?>
                </ul>
            </div>

            <div class="col-3">
                <ul class="nav justify-content-center">
                    <span class="text-black nav-link" >
                        <?=Session::getSessionUser()->email?>
                    </span>
                </ul>
            </div>

            <div class="col-1"></div>

            <div class="col-8">
                <?php
                    $links = array(
                        "envision.php" => "Step 1 - Envision",
                        "assess.php" => "Step 2 - Assess",
                        "goals.php" => "Step 3 - Goals and Action Plan",
                        "reassess.php" => "Step 4 - Reassess",
                        "report.php" => "Report"
                    );
                ?>
                <ul class="nav justify-content-start <?=shouldHideSubNav($links)?>">
                    <?php
                        foreach($links as $link => $val) {
                            ?>
                            <a class="nav-link <?=highlightNavPage($link)?>" aria-current="page" href="<?=$link?>"><?=$val?></a>
                            <?php
                        }
                    ?>
                </ul>
            </div>
        </div><br />

<?php
}
?>